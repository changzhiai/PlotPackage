# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 23:49:22 2021

@author: changai
"""

'to do list'

'1. normalize plot style'

'2. '