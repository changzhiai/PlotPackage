# -*- coding: utf-8 -*-
"""
Created on Wed Jan  5 15:26:52 2022

@author: changai
"""

#import parent dirs for local
import sys
sys.path.append("../..")